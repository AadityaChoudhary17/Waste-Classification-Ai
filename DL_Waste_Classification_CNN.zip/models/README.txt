The trained .keras model will be created here after running src/train.py.
